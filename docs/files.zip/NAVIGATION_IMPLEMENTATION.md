# Navigation Recommendations Implementation

> Replaces the `NavigationAbilities::recommend_navigation()` 501 stub with a working pipeline.
> WordPress 7.0 / Gutenberg 22.8 compatible.

## Files to Add

### `inc/LLM/NavigationPrompt.php` (new)

System/user prompt assembly + response parsing for navigation recommendations. Follows `TemplatePrompt.php` exactly.

### `tests/phpunit/NavigationAbilitiesTest.php` (new)

12 unit tests covering input validation, prompt assembly, response parsing, and system prompt content.

## Files to Replace

### `inc/Abilities/NavigationAbilities.php` (replace 501 stub)

Full implementation: normalize input → `ServerCollector::for_navigation()` → `NavigationPrompt::build_system/user()` → `ResponsesClient::rank()` → `NavigationPrompt::parse_response()`.

## Files to Patch

### `inc/Context/ServerCollector.php`

Add 7 methods. Insert before the final closing brace of the class:

- `for_navigation()` — public, main context builder
- `find_navigation_block()` — private
- `extract_menu_items()` — private
- `simplify_block_name()` — private
- `extract_string_attr()` — private
- `count_menu_items_recursive()` — private
- `measure_menu_depth()` — private
- `infer_navigation_location()` — private

The complete method bodies are in `inc/Context/ServerCollector_navigation_addition.php`.

### `tests/phpunit/bootstrap.php`

Three changes needed:

#### 1. Add `$posts` property to `WordPressTestState`

```php
// After: public static array $settings_errors = [];
public static array $posts = [];
```

#### 2. Add `self::$posts = [];` to `reset()`

```php
// After: self::$settings_errors = [];
self::$posts = [];
```

#### 3. Add function stubs (in the global namespace block, before `require`)

```php
if ( ! function_exists( 'get_post' ) ) {
    function get_post( $post_id = null ) {
        if ( $post_id === null ) {
            return null;
        }
        $id = (int) ( is_object( $post_id ) ? ( $post_id->ID ?? 0 ) : $post_id );
        return WordPressTestState::$posts[ $id ] ?? null;
    }
}

if ( ! function_exists( 'parse_blocks' ) ) {
    function parse_blocks( string $content ): array {
        $blocks  = [];
        $pattern = '/<!--\s+wp:([a-z][a-z0-9-]*(?:\/[a-z][a-z0-9-]*)?)\s*(\{[^}]*\})?\s*(\/)?-->/';
        $offset  = 0;

        while ( preg_match( $pattern, $content, $match, PREG_OFFSET_CAPTURE, $offset ) ) {
            $full_match = $match[0][0];
            $match_pos  = $match[0][1];
            $block_name = 'core/' . $match[1][0];

            if ( str_contains( $match[1][0], '/' ) ) {
                $block_name = $match[1][0];
            }

            $attrs_json   = $match[2][0] ?? '';
            $self_closing = ! empty( $match[3][0] );

            $attrs = [];
            if ( $attrs_json !== '' ) {
                $decoded = json_decode( $attrs_json, true );
                if ( is_array( $decoded ) ) {
                    $attrs = $decoded;
                }
            }

            if ( $self_closing ) {
                $blocks[] = [
                    'blockName'    => $block_name,
                    'attrs'        => $attrs,
                    'innerBlocks'  => [],
                    'innerHTML'    => '',
                    'innerContent' => [],
                ];
                $offset = $match_pos + strlen( $full_match );
            } else {
                $close_tag = '<!-- /wp:' . $match[1][0] . ' -->';
                $close_pos = strpos( $content, $close_tag, $match_pos + strlen( $full_match ) );

                if ( $close_pos !== false ) {
                    $inner_html = substr(
                        $content,
                        $match_pos + strlen( $full_match ),
                        $close_pos - ( $match_pos + strlen( $full_match ) )
                    );

                    $blocks[] = [
                        'blockName'    => $block_name,
                        'attrs'        => $attrs,
                        'innerBlocks'  => parse_blocks( $inner_html ),
                        'innerHTML'    => $inner_html,
                        'innerContent' => [ $inner_html ],
                    ];

                    $offset = $close_pos + strlen( $close_tag );
                } else {
                    $offset = $match_pos + strlen( $full_match );
                }
            }
        }

        return $blocks;
    }
}
```

## Doc Updates

### `STATUS.md`

Move `recommend-navigation` from Stubbed to Working:

**Remove from Stubbed section:**
```
| `flavor-agent/recommend-navigation` | `edit_theme_options` | Navigation recommendation implementation |
```

**Add to Abilities API table:**
```
| `flavor-agent/recommend-navigation` | `NavigationAbilities` | Navigation structure, overlay behavior, and organization recommendations |
```

### `SOURCE_OF_TRUTH.md`

**Check off in Must Have:**
```
- [x] Navigation recommendations (replace 501 stub)
```

**Update Abilities API table:**
```
| `flavor-agent/recommend-navigation` | `NavigationAbilities` | `edit_theme_options` | Working |
```

**Remove from Stubbed section** and **Known Issues** where applicable.

**Add data flow diagram:**
```
### Navigation Recommendation Flow
External AI agent calls flavor-agent/recommend-navigation ability
  -> NavigationAbilities::recommend_navigation(input)
     -> ServerCollector::for_navigation(menuId, markup)
        -> get_post(menuId) for wp_navigation content
        -> parse_blocks() to extract menu item tree
        -> Extract navigation block attributes
        -> for_template_parts('navigation-overlay') for WP 7.0 overlay parts
        -> infer_navigation_location() from template part refs
        -> for_tokens() for theme design tokens
     -> AISearchClient::maybe_search_with_entity_fallback()
     -> NavigationPrompt::build_system() + build_user()
     -> ResponsesClient::rank(instructions, input)
     -> NavigationPrompt::parse_response() (validates categories, change types)
  <- JSON response: { suggestions, explanation }
```

### `CLAUDE.md`

Add `NavigationPrompt` to the LLM namespace table:
```
| `LLM\NavigationPrompt` | Navigation recommendation prompt assembly and response parsing |
```

## WP 7.0 Compatibility Notes

- `navigation-overlay` is a first-class template-part area (stabilized from experimental)
- System prompt instructs the LLM to prefer overlay template parts over inline overlay config
- `core/navigation-link` and `core/navigation-submenu` have block binding support (new in WP 7.0)
- `core/home-link` recognized as distinct inner block type
- `parse_blocks()` handles the standard Gutenberg block grammar

## Test Expectations

After integration, running `vendor/bin/phpunit` should show the new tests passing:
- 12 new tests in `NavigationAbilitiesTest`
- Total test count goes from 51 to 63
