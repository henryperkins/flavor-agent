/**
 * Template Recommender
 *
 * Renders AI template composition suggestions in the Site Editor's
 * document sidebar via PluginDocumentSettingPanel.
 */
import { Button, Notice, TextareaControl } from '@wordpress/components';
import { useDispatch, useSelect } from '@wordpress/data';
import { PluginDocumentSettingPanel } from '@wordpress/editor';
import { useEffect, useRef, useState } from '@wordpress/element';

import { STORE_NAME } from '../store';
import { normalizeTemplateType } from '../utils/template-types';
import { getVisiblePatternNames } from '../utils/visible-patterns';

export default function TemplateRecommender() {
	const canRecommend = window.flavorAgentData?.canRecommendTemplates;
	const templateRef = useSelect( ( select ) => {
		const editSite = select( 'core/edit-site' );

		if ( ! editSite?.getEditedPostType || ! editSite?.getEditedPostId ) {
			return null;
		}

		if ( editSite.getEditedPostType() !== 'wp_template' ) {
			return null;
		}

		const editedPostId = editSite.getEditedPostId();

		return typeof editedPostId === 'string' && editedPostId !== ''
			? editedPostId
			: null;
	}, [] );
	const templateType = normalizeTemplateType( templateRef );
	const { recommendations, explanation, error, resultRef, isLoading } =
		useSelect( ( select ) => {
			const store = select( STORE_NAME );

			return {
				recommendations: store.getTemplateRecommendations(),
				explanation: store.getTemplateExplanation(),
				error: store.getTemplateError(),
				resultRef: store.getTemplateResultRef(),
				isLoading: store.isTemplateLoading(),
			};
		}, [] );
	const patternTitleMap = useSelect( ( select ) => {
		const blockEditor = select( 'core/block-editor' );
		const settings = blockEditor?.getSettings?.() || {};
		const patterns = Array.isArray( settings.__experimentalBlockPatterns )
			? settings.__experimentalBlockPatterns
			: [];

		return patterns.reduce( ( acc, pattern ) => {
			if ( pattern?.name ) {
				acc[ pattern.name ] = pattern.title || pattern.name;
			}

			return acc;
		}, {} );
	}, [] );
	const { fetchTemplateRecommendations, clearTemplateRecommendations } =
		useDispatch( STORE_NAME );
	const [ prompt, setPrompt ] = useState( '' );
	const previousTemplateRef = useRef( templateRef );

	useEffect( () => {
		if ( previousTemplateRef.current === templateRef ) {
			return;
		}

		clearTemplateRecommendations();
		setPrompt( '' );
		previousTemplateRef.current = templateRef;
	}, [ templateRef, clearTemplateRecommendations ] );

	const hasMatchingResult = resultRef === templateRef;
	const hasSuggestions = hasMatchingResult && recommendations.length > 0;

	const handleFetch = () => {
		const input = {
			templateRef,
			visiblePatternNames: getVisiblePatternNames(),
		};
		const trimmedPrompt = prompt.trim();

		if ( templateType ) {
			input.templateType = templateType;
		}

		if ( trimmedPrompt ) {
			input.prompt = trimmedPrompt;
		}

		fetchTemplateRecommendations( input );
	};

	if ( ! canRecommend || ! templateRef ) {
		return null;
	}

	return (
		<PluginDocumentSettingPanel
			name="flavor-agent-template-recommendations"
			title="AI Template Recommendations"
		>
			<TextareaControl
				__nextHasNoMarginBottom
				label="What are you trying to achieve with this template?"
				hideLabelFromVision
				placeholder="Describe the structure or layout you want."
				value={ prompt }
				onChange={ setPrompt }
				rows={ 3 }
				className="flavor-agent-prompt"
			/>

			<Button
				variant="primary"
				onClick={ handleFetch }
				disabled={ isLoading }
				className="flavor-agent-fetch-button"
			>
				{ isLoading ? 'Getting suggestions…' : 'Get Suggestions' }
			</Button>

			{ isLoading && (
				<Notice
					status="info"
					isDismissible={ false }
				>
					Analyzing template structure…
				</Notice>
			) }

			{ error && (
				<Notice
					status="error"
					isDismissible={ false }
				>
					{ error }
				</Notice>
			) }

			{ hasMatchingResult && explanation && (
				<p className="flavor-agent-explanation">
					{ explanation }
				</p>
			) }

			{ hasSuggestions &&
				recommendations.map( ( suggestion, index ) => (
					<TemplateSuggestionCard
						key={ `${ suggestion.label }-${ index }` }
						suggestion={ suggestion }
						patternTitleMap={ patternTitleMap }
					/>
				) ) }
		</PluginDocumentSettingPanel>
	);
}

function TemplateSuggestionCard( { suggestion, patternTitleMap = {} } ) {
	return (
		<div className="flavor-agent-card flavor-agent-card--template">
			<div className="flavor-agent-card__label">
				{ suggestion.label }
			</div>

			{ suggestion.description && (
				<p className="flavor-agent-card__description">
					{ suggestion.description }
				</p>
			) }

			{ suggestion.templateParts?.length > 0 && (
				<div className="flavor-agent-template-list">
					<div className="flavor-agent-section-label">
						Template Parts
					</div>
					{ suggestion.templateParts.map( ( templatePart ) => (
						<div
							key={ `${ templatePart.slug }-${ templatePart.area }` }
							className="flavor-agent-template-list__item"
						>
							<code>{ templatePart.slug }</code>
							{ ' → ' }
							{ templatePart.area }
							{ templatePart.reason && (
								<span className="flavor-agent-template-list__reason">
									{ ' — ' }
									{ templatePart.reason }
								</span>
							) }
						</div>
					) ) }
				</div>
			) }

			{ suggestion.patternSuggestions?.length > 0 && (
				<div>
					<div className="flavor-agent-section-label">
						Suggested Patterns
					</div>
					{ suggestion.patternSuggestions.map( ( name ) => (
						<div
							key={ name }
							className="flavor-agent-template-list__item"
						>
							{ patternTitleMap[ name ] || (
								<code>{ name }</code>
							) }
						</div>
					) ) }
				</div>
			) }
		</div>
	);
}
