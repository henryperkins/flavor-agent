# Block Identity Integration Guide

## Overview

`src/utils/block-identity.js` replaces `src/utils/template-part-areas.js` and becomes the single identity resolver used by three consumers:

1. **`src/utils/template-actions.js`** — action matcher (findBlockByArea, assignTemplatePart)
2. **`src/context/block-inspector.js`** — context builder (summarizeTree)
3. **`src/templates/TemplateRecommender.js`** — entity linker (buildEntityMap)

After integration, delete `src/utils/template-part-areas.js`.

---

## 1. `src/utils/template-actions.js`

### Current (after the area-inference patch)

```js
import { matchesTemplatePartArea } from './template-part-areas';

// in findBlockByArea():
const empty = findTemplatePart(
    blocks,
    ( b ) => matchesTemplatePartArea( b, area ) && ! b.attributes?.slug
);

return (
    empty ||
    findTemplatePart( blocks, ( b ) => matchesTemplatePartArea( b, area ) )
);
```

### New

```js
import { matchesArea, getDefaultLookups } from './block-identity';

// Cache lookups once per call rather than per-block.
// getDefaultLookups() reads the localized PHP bridge — cheap, but no
// reason to re-read it for every predicate invocation in a tree walk.

export function findBlockByArea( area ) {
    const blocks = getBlocks();
    const lookups = getDefaultLookups();

    const empty = findTemplatePart(
        blocks,
        ( b ) => matchesArea( b, area, lookups ) && ! b.attributes?.slug
    );

    return (
        empty ||
        findTemplatePart( blocks, ( b ) => matchesArea( b, area, lookups ) )
    );
}
```

Drop the `import { matchesTemplatePartArea }` line. The `matchesArea` function is a drop-in replacement with the same `(block, area, lookups?) → boolean` contract, but it also gates on `block.name === 'core/template-part'` internally so callers don't need to.

---

## 2. `src/context/block-inspector.js` — `summarizeTree`

### Current

```js
export function summarizeTree( tree ) {
    return tree.map( ( node ) => {
        const summary = {
            block: node.name,
            title: node.title,
        };
        // ... existing fields ...
        return summary;
    } );
}
```

### New

```js
import { resolveBlockIdentity, getDefaultLookups } from '../utils/block-identity';

export function summarizeTree( tree, lookups ) {
    if ( ! lookups ) {
        lookups = getDefaultLookups();
    }

    return tree.map( ( node ) => {
        const summary = {
            block: node.name,
            title: node.title,
        };

        // Canonical identity — what this block IS, not just its JSON.
        const identity = resolveBlockIdentity( node, lookups );
        if ( identity.role ) {
            summary.role = identity.role;
        }
        if ( identity.area ) {
            summary.area = identity.area;
        }

        // ... rest of existing fields unchanged ...

        if ( node.innerBlocks.length ) {
            summary.children = summarizeTree( node.innerBlocks, lookups );
        }

        return summary;
    } );
}
```

This means the LLM prompt tree goes from:

```json
{ "block": "core/template-part", "title": "Template Part", "currentValues": { "slug": "footer" } }
```

to:

```json
{ "block": "core/template-part", "title": "Template Part", "role": "footer", "area": "footer", "currentValues": { "slug": "footer" } }
```

The model can now match on `role` without parsing raw attributes.

---

## 3. `src/templates/TemplateRecommender.js` — `buildEntityMap`

### Current

The entity map is built by iterating suggestion objects and manually extracting slug/area/pattern-name strings:

```js
function buildEntityMap( recommendations, patternTitleMap ) {
    const map = new Map();

    for ( const s of recommendations ) {
        if ( s.templateParts?.length > 0 ) {
            for ( const part of s.templateParts ) {
                if ( part.slug && ! map.has( part.slug ) ) {
                    const slug = part.slug;
                    const area = part.area;
                    map.set( slug, {
                        text: slug,
                        type: ENTITY_PART,
                        action: () => selectBlockBySlugOrArea( slug, area ),
                        // ...
                    } );
                }
                // ...
            }
        }
    }
    // ...
}
```

### New

No structural change needed here — `buildEntityMap` works with LLM output strings, not live blocks. The fix is that `selectBlockBySlugOrArea` → `selectBlockByArea` → `findBlockByArea` now uses the resolver internally, so the entity actions already work.

However, if you want the entity map to also carry resolved identity for rendering hints (e.g. showing "Footer slot" instead of just "footer" in the tooltip), add:

```js
import { resolveBlockIdentity, getDefaultLookups } from '../utils/block-identity';

// In the entity creation for template parts:
const lookups = getDefaultLookups();
const identity = resolveBlockIdentity(
    {
        name: 'core/template-part',
        attributes: { slug, area },
    },
    lookups
);

map.set( slug, {
    text: slug,
    type: ENTITY_PART,
    identity,  // downstream renderers can use identity.role
    action: () => selectBlockBySlugOrArea( slug, area ),
    tooltip: identity.role
        ? `Select "${ slug }" (${ identity.role } slot) in editor`
        : `Select "${ slug }" block in editor`,
} );
```

This is optional — the critical path (actions working) is already fixed by the resolver in `findBlockByArea`.

---

## 4. `src/context/collector.js` — `collectBlockContext`

### Current

```js
return {
    block: {
        name: instance.name,
        title: instance.title,
        // ...
    },
    // ...
};
```

### New

```js
import { resolveBlockIdentity, getDefaultLookups } from '../utils/block-identity';

// After introspecting the instance:
const identity = resolveBlockIdentity( instance, getDefaultLookups() );

return {
    block: {
        name: instance.name,
        title: instance.title,
        role: identity.role,
        area: identity.area || undefined,
        // ... rest unchanged ...
    },
    // ...
};
```

This means the per-block context sent to the REST endpoint also carries `role`, so the PHP prompt builder can use it without re-deriving.

---

## 5. Delete `src/utils/template-part-areas.js`

After the above changes are in, `template-part-areas.js` is dead code.
Its three exports map directly to the new module:

| Old (template-part-areas.js)       | New (block-identity.js)       |
|------------------------------------|-------------------------------|
| `inferTemplatePartArea(attrs, map)` | `resolveTemplatePartArea(attrs, { templatePartAreas: map })` |
| `matchesTemplatePartArea(block, area, map)` | `matchesArea(block, area, { templatePartAreas: map })` |
| `getTemplatePartAreaLookup()`       | `getDefaultLookups().templatePartAreas` |

Delete the file and its test (`src/utils/__tests__/template-part-areas.test.js`) — the new test file covers the same cases plus the broader identity resolver.

---

## PHP side: no changes needed

`flavor-agent.php` already localizes `templatePartAreas`. `ServerCollector` already resolves areas from the part registry. The PHP prompt builder already has correct identity because it controls the context assembly. This change is purely client-side — making the JS match the PHP's existing capability.
