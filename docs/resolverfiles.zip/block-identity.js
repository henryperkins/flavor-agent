/**
 * Block Identity Resolver
 *
 * Derives canonical identity for any block visible in the editor
 * from multiple evidence signals — not just raw JSON attributes.
 *
 * The editor serializes blocks inconsistently: a footer template-part
 * might carry `{ slug: "footer", area: "footer" }` or just
 * `{ slug: "footer", theme: "my-theme" }` with no area at all.
 * The block name `core/template-part` tells you the kind but not
 * the role. This module resolves the role from whatever the editor
 * can actually prove about the thing on screen.
 *
 * Evidence tiers (checked in order):
 *   1. Explicit attribute  — attrs.area, attrs.slug
 *   2. Registry lookup     — slug → area from the template-part registry
 *   3. Structural hint     — tagName, block name patterns
 *
 * Pure function: no store access, no globals.
 * Consumers pass in `lookups` with whatever registry data they have.
 */

/**
 * Known block names that map directly to a semantic role.
 * These are singleton-ish blocks whose name IS their identity.
 */
const BLOCK_NAME_ROLES = {
	'core/navigation': 'navigation',
	'core/site-title': 'site-title',
	'core/site-logo': 'site-logo',
	'core/site-tagline': 'site-tagline',
	'core/query': 'query-loop',
	'core/post-content': 'post-content',
	'core/post-title': 'post-title',
	'core/post-featured-image': 'featured-image',
	'core/post-excerpt': 'post-excerpt',
	'core/post-terms': 'post-terms',
	'core/post-date': 'post-date',
	'core/post-author': 'post-author',
	'core/post-author-name': 'post-author',
	'core/comments': 'comments',
	'core/post-comments-form': 'comments-form',
	'core/loginout': 'login',
	'core/search': 'search',
};

/**
 * HTML tag names that imply a template-part area.
 */
const TAG_TO_AREA = {
	header: 'header',
	footer: 'footer',
	aside: 'sidebar',
	nav: 'header', // nav tag on a template-part usually means header-nav
};

/**
 * Well-known slugs that imply an area even without a registry.
 * Only used as a last resort when the registry lookup has nothing.
 */
const SLUG_AREA_FALLBACKS = {
	header: 'header',
	footer: 'footer',
	sidebar: 'sidebar',
};

/**
 * Resolve the canonical identity of a block.
 *
 * @param {Object}  block               Block-like object with at least `name`.
 * @param {Object}  block.name          Block name, e.g. 'core/template-part'.
 * @param {Object}  [block.attributes]  Current block attributes.
 * @param {Object}  [lookups]           External registry data.
 * @param {Object}  [lookups.templatePartAreas]  Map of slug → area from PHP.
 * @return {Object} Identity descriptor: { kind, role, area?, slug? }
 */
export function resolveBlockIdentity( block, lookups = {} ) {
	if ( ! block?.name ) {
		return { kind: 'unknown', role: null };
	}

	if ( block.name === 'core/template-part' ) {
		return resolveTemplatePart( block.attributes || {}, lookups );
	}

	const role = BLOCK_NAME_ROLES[ block.name ] || null;

	return {
		kind: role ? 'site-chrome' : 'block',
		role,
	};
}

/**
 * Resolve identity for a core/template-part block.
 * This is the main place where multi-signal evidence matters.
 *
 * @param {Object} attrs   Block attributes.
 * @param {Object} lookups Registry data.
 * @return {Object} Identity with kind='template-part'.
 */
function resolveTemplatePart( attrs, lookups ) {
	const slug = typeof attrs.slug === 'string' ? attrs.slug : '';
	const area = resolveTemplatePartArea( attrs, lookups );

	return {
		kind: 'template-part',
		role: area || null,
		area: area || null,
		slug: slug || null,
	};
}

/**
 * Resolve the area of a template-part from available evidence.
 *
 * Priority:
 *   1. Explicit `area` attribute — the editor put it there, trust it.
 *   2. Registry lookup — PHP knows slug → area from the parts registry.
 *   3. Slug name match — header/footer/sidebar slugs are self-evident.
 *   4. tagName hint — `<footer>` tag means footer area.
 *   5. Give up — return empty string.
 *
 * @param {Object} attrs               Block attributes.
 * @param {Object} [lookups]           Registry data.
 * @param {Object} [lookups.templatePartAreas] Slug → area map.
 * @return {string} Resolved area or ''.
 */
export function resolveTemplatePartArea( attrs, lookups = {} ) {
	if ( ! attrs || typeof attrs !== 'object' ) {
		return '';
	}

	// 1. Explicit attribute
	if ( typeof attrs.area === 'string' && attrs.area !== '' ) {
		return attrs.area;
	}

	const slug = typeof attrs.slug === 'string' ? attrs.slug : '';
	const areaMap = lookups.templatePartAreas;

	// 2. Registry lookup
	if ( slug !== '' && areaMap && typeof areaMap[ slug ] === 'string' ) {
		return areaMap[ slug ];
	}

	// 3. Slug fallback
	if ( slug !== '' && SLUG_AREA_FALLBACKS[ slug ] ) {
		return SLUG_AREA_FALLBACKS[ slug ];
	}

	// 4. tagName hint
	const tag = typeof attrs.tagName === 'string' ? attrs.tagName : '';
	if ( tag !== '' && TAG_TO_AREA[ tag ] ) {
		return TAG_TO_AREA[ tag ];
	}

	return '';
}

/**
 * Check whether a block matches a target area.
 *
 * Drop-in replacement for the old `b.attributes?.area === area` check
 * that failed when area was missing from serialized attrs.
 *
 * @param {Object} block        Block with at least { attributes }.
 * @param {string} targetArea   Area to match against.
 * @param {Object} [lookups]    Registry data.
 * @return {boolean}
 */
export function matchesArea( block, targetArea, lookups = {} ) {
	if ( block?.name !== 'core/template-part' ) {
		return false;
	}
	return resolveTemplatePartArea( block.attributes || {}, lookups ) === targetArea;
}

/**
 * Get the localized template-part area lookup from the PHP bridge.
 * Convenience for consumers that don't have their own lookups bag.
 *
 * @return {Object} The lookups object with templatePartAreas populated.
 */
export function getDefaultLookups() {
	const areas =
		typeof window !== 'undefined'
			? window.flavorAgentData?.templatePartAreas
			: null;

	return {
		templatePartAreas:
			areas && typeof areas === 'object' ? areas : {},
	};
}
