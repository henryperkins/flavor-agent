import {
	resolveBlockIdentity,
	resolveTemplatePartArea,
	matchesArea,
} from '../block-identity';

/* ------------------------------------------------------------------ */
/*  resolveBlockIdentity                                               */
/* ------------------------------------------------------------------ */

describe( 'resolveBlockIdentity', () => {
	test( 'returns unknown for null/undefined input', () => {
		expect( resolveBlockIdentity( null ) ).toEqual( {
			kind: 'unknown',
			role: null,
		} );
		expect( resolveBlockIdentity( {} ) ).toEqual( {
			kind: 'unknown',
			role: null,
		} );
	} );

	test( 'resolves template-part with explicit area', () => {
		const result = resolveBlockIdentity( {
			name: 'core/template-part',
			attributes: { slug: 'footer', area: 'footer' },
		} );
		expect( result ).toEqual( {
			kind: 'template-part',
			role: 'footer',
			area: 'footer',
			slug: 'footer',
		} );
	} );

	test( 'resolves template-part without area via registry', () => {
		const result = resolveBlockIdentity(
			{
				name: 'core/template-part',
				attributes: {
					slug: 'footer-newsletter',
					theme: 'henrys-digital-canvas',
				},
			},
			{ templatePartAreas: { 'footer-newsletter': 'footer' } }
		);
		expect( result ).toEqual( {
			kind: 'template-part',
			role: 'footer',
			area: 'footer',
			slug: 'footer-newsletter',
		} );
	} );

	test( 'resolves template-part without area via slug fallback', () => {
		const result = resolveBlockIdentity( {
			name: 'core/template-part',
			attributes: { slug: 'header' },
		} );
		expect( result ).toEqual( {
			kind: 'template-part',
			role: 'header',
			area: 'header',
			slug: 'header',
		} );
	} );

	test( 'resolves template-part without area via tagName', () => {
		const result = resolveBlockIdentity( {
			name: 'core/template-part',
			attributes: { slug: 'my-custom-footer', tagName: 'footer' },
		} );
		expect( result ).toEqual( {
			kind: 'template-part',
			role: 'footer',
			area: 'footer',
			slug: 'my-custom-footer',
		} );
	} );

	test( 'resolves template-part with no evidence to null role', () => {
		const result = resolveBlockIdentity( {
			name: 'core/template-part',
			attributes: { slug: 'custom-widget-area' },
		} );
		expect( result ).toEqual( {
			kind: 'template-part',
			role: null,
			area: null,
			slug: 'custom-widget-area',
		} );
	} );

	test( 'resolves well-known site-chrome blocks', () => {
		expect( resolveBlockIdentity( { name: 'core/navigation' } ) ).toEqual( {
			kind: 'site-chrome',
			role: 'navigation',
		} );
		expect( resolveBlockIdentity( { name: 'core/site-title' } ) ).toEqual( {
			kind: 'site-chrome',
			role: 'site-title',
		} );
		expect( resolveBlockIdentity( { name: 'core/post-content' } ) ).toEqual( {
			kind: 'site-chrome',
			role: 'post-content',
		} );
	} );

	test( 'resolves generic blocks', () => {
		expect(
			resolveBlockIdentity( { name: 'core/paragraph' } )
		).toEqual( { kind: 'block', role: null } );
		expect(
			resolveBlockIdentity( { name: 'my-plugin/fancy-slider' } )
		).toEqual( { kind: 'block', role: null } );
	} );

	test( 'explicit area wins over registry lookup', () => {
		const result = resolveBlockIdentity(
			{
				name: 'core/template-part',
				attributes: { slug: 'footer', area: 'sidebar' },
			},
			{ templatePartAreas: { footer: 'footer' } }
		);
		expect( result.area ).toBe( 'sidebar' );
	} );
} );

/* ------------------------------------------------------------------ */
/*  resolveTemplatePartArea                                            */
/* ------------------------------------------------------------------ */

describe( 'resolveTemplatePartArea', () => {
	test( 'returns empty string for missing/null attrs', () => {
		expect( resolveTemplatePartArea( null ) ).toBe( '' );
		expect( resolveTemplatePartArea( undefined ) ).toBe( '' );
		expect( resolveTemplatePartArea( {} ) ).toBe( '' );
	} );

	test( 'prefers explicit area over everything', () => {
		expect(
			resolveTemplatePartArea(
				{ area: 'footer', slug: 'header' },
				{ templatePartAreas: { header: 'header' } }
			)
		).toBe( 'footer' );
	} );

	test( 'falls back to registry when area is missing', () => {
		expect(
			resolveTemplatePartArea(
				{ slug: 'footer-columns' },
				{ templatePartAreas: { 'footer-columns': 'footer' } }
			)
		).toBe( 'footer' );
	} );

	test( 'falls back to slug name for header/footer/sidebar', () => {
		expect( resolveTemplatePartArea( { slug: 'sidebar' } ) ).toBe(
			'sidebar'
		);
	} );

	test( 'falls back to tagName as last resort', () => {
		expect(
			resolveTemplatePartArea( { slug: 'whatever', tagName: 'aside' } )
		).toBe( 'sidebar' );
	} );

	test( 'returns empty string when no evidence matches', () => {
		expect(
			resolveTemplatePartArea( { slug: 'totally-custom' } )
		).toBe( '' );
	} );
} );

/* ------------------------------------------------------------------ */
/*  matchesArea                                                        */
/* ------------------------------------------------------------------ */

describe( 'matchesArea', () => {
	test( 'returns false for non-template-part blocks', () => {
		expect(
			matchesArea( { name: 'core/paragraph', attributes: {} }, 'footer' )
		).toBe( false );
	} );

	test( 'matches on explicit area', () => {
		expect(
			matchesArea(
				{
					name: 'core/template-part',
					attributes: { area: 'footer', slug: 'footer' },
				},
				'footer'
			)
		).toBe( true );
	} );

	test( 'matches on inferred area from registry', () => {
		expect(
			matchesArea(
				{
					name: 'core/template-part',
					attributes: { slug: 'footer-newsletter' },
				},
				'footer',
				{ templatePartAreas: { 'footer-newsletter': 'footer' } }
			)
		).toBe( true );
	} );

	test( 'does not match wrong area', () => {
		expect(
			matchesArea(
				{
					name: 'core/template-part',
					attributes: { slug: 'footer', area: 'footer' },
				},
				'header'
			)
		).toBe( false );
	} );

	test( 'matches on slug fallback', () => {
		expect(
			matchesArea(
				{
					name: 'core/template-part',
					attributes: { slug: 'header' },
				},
				'header'
			)
		).toBe( true );
	} );
} );
